﻿using System;
using System.Collections.Generic;

#nullable disable

namespace UnitFourMVC
{
    public partial class HarringtonOrderLine
    {
        public int OrderNumb { get; set; }
        public string Isbn { get; set; }
        public int Quantity { get; set; }
        public decimal CostEach { get; set; }
        public decimal CostLine { get; set; }
        public string Shipped { get; set; }
    }
}
