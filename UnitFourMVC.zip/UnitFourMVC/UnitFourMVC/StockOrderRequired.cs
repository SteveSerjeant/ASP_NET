﻿using System;
using System.Collections.Generic;

#nullable disable

namespace UnitFourMVC
{
    public partial class StockOrderRequired
    {
        public int ProductId { get; set; }
        public string ProductDetails { get; set; }
        public int Quantity { get; set; }
    }
}
