﻿using System;
using System.Collections.Generic;

#nullable disable

namespace UnitFourMVC
{
    public partial class StockOrder
    {
        public int StockOrderId { get; set; }
        public int Productid { get; set; }
        public string ProductDetails { get; set; }
        public int Quantity { get; set; }
        public DateTime Updated { get; set; }
    }
}
