﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace UnitFourMVC
{
    public partial class COMP2001_SSerjeantContext : DbContext
    {
        public COMP2001_SSerjeantContext()
        {
        }

        public COMP2001_SSerjeantContext(DbContextOptions<COMP2001_SSerjeantContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Customer> Customers { get; set; }
        public virtual DbSet<HarringtonAuthor> HarringtonAuthors { get; set; }
        public virtual DbSet<HarringtonBook> HarringtonBooks { get; set; }
        public virtual DbSet<HarringtonCustomer> HarringtonCustomers { get; set; }
        public virtual DbSet<HarringtonOrder> HarringtonOrders { get; set; }
        public virtual DbSet<HarringtonOrderLine> HarringtonOrderLines { get; set; }
        public virtual DbSet<HarringtonPublisher> HarringtonPublishers { get; set; }
        public virtual DbSet<HarringtonSource> HarringtonSources { get; set; }
        public virtual DbSet<Order> Orders { get; set; }
        public virtual DbSet<OrderDetail> OrderDetails { get; set; }
        public virtual DbSet<OrdersByMonth> OrdersByMonths { get; set; }
        public virtual DbSet<OrdersCustomer> OrdersCustomers { get; set; }
        public virtual DbSet<PriceAudit> PriceAudits { get; set; }
        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<SalesByCustomer> SalesByCustomers { get; set; }
        public virtual DbSet<SalesByMonth> SalesByMonths { get; set; }
        public virtual DbSet<SalesCustomerFloat> SalesCustomerFloats { get; set; }
        public virtual DbSet<StockOrder> StockOrders { get; set; }
        public virtual DbSet<StockOrderRequired> StockOrderRequireds { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=socem1.uopnet.plymouth.ac.uk;Database=COMP2001_SSerjeant;User Id=SSerjeant; Password=ZouQ516+");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Customer>(entity =>
            {
                entity.Property(e => e.CustomerId).HasColumnName("CustomerID");

                entity.Property(e => e.CustAddr1)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .HasColumnName("Cust_Addr1");

                entity.Property(e => e.CustAddr2)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .HasColumnName("Cust_Addr2");

                entity.Property(e => e.CustName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("Cust_Name");

                entity.Property(e => e.CustPostcode)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("Cust_Postcode");
            });

            modelBuilder.Entity<HarringtonAuthor>(entity =>
            {
                entity.HasKey(e => e.AuthorName)
                    .HasName("PK__harringt__EC91C5294CB9B723");

                entity.ToTable("harrington_authors");

                entity.Property(e => e.AuthorName)
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .HasColumnName("author_name");
            });

            modelBuilder.Entity<HarringtonBook>(entity =>
            {
                entity.HasKey(e => e.Isbn)
                    .HasName("PK__harringt__99F9D0A599B0A6E8");

                entity.ToTable("harrington_books");

                entity.Property(e => e.Isbn)
                    .HasMaxLength(12)
                    .IsUnicode(false)
                    .HasColumnName("isbn")
                    .IsFixedLength(true);

                entity.Property(e => e.AuthorName)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .HasColumnName("author_name");

                entity.Property(e => e.Binding)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("binding")
                    .IsFixedLength(true);

                entity.Property(e => e.NumberOnHand).HasColumnName("number_on_hand");

                entity.Property(e => e.PublicationYear)
                    .IsRequired()
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("publication_year")
                    .IsFixedLength(true);

                entity.Property(e => e.PublisherName)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .HasColumnName("publisher_name");

                entity.Property(e => e.RetailPrice)
                    .HasColumnType("decimal(6, 2)")
                    .HasColumnName("retail_price");

                entity.Property(e => e.SourceNumb).HasColumnName("source_numb");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false)
                    .HasColumnName("title");
            });

            modelBuilder.Entity<HarringtonCustomer>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("harrington_customers");

                entity.Property(e => e.CustomerCity)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("customer_city");

                entity.Property(e => e.CustomerEmail)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .HasColumnName("customer_email");

                entity.Property(e => e.CustomerFirstName)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("customer_first_name");

                entity.Property(e => e.CustomerLastName)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("customer_last_name");

                entity.Property(e => e.CustomerNumb).HasColumnName("customer_numb");

                entity.Property(e => e.CustomerPhone)
                    .IsRequired()
                    .HasMaxLength(12)
                    .IsUnicode(false)
                    .HasColumnName("customer_phone")
                    .IsFixedLength(true);

                entity.Property(e => e.CustomerState)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("customer_state")
                    .IsFixedLength(true);

                entity.Property(e => e.CustomerStreet)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("customer_street");

                entity.Property(e => e.CustomerZip)
                    .IsRequired()
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("customer_zip")
                    .IsFixedLength(true);
            });

            modelBuilder.Entity<HarringtonOrder>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("harrington_orders");

                entity.Property(e => e.CreditCardExpirationDate)
                    .IsRequired()
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("credit_card_expiration_date")
                    .IsFixedLength(true);

                entity.Property(e => e.CreditCardNumb)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("credit_card_numb");

                entity.Property(e => e.CustomerNumb).HasColumnName("customer_numb");

                entity.Property(e => e.OrderDate)
                    .HasColumnType("datetime")
                    .HasColumnName("order_date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.OrderFilled)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("order_filled")
                    .HasDefaultValueSql("('N')")
                    .IsFixedLength(true);

                entity.Property(e => e.OrderNumb).HasColumnName("order_numb");
            });

            modelBuilder.Entity<HarringtonOrderLine>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("harrington_order_lines");

                entity.Property(e => e.CostEach)
                    .HasColumnType("decimal(6, 2)")
                    .HasColumnName("cost_each");

                entity.Property(e => e.CostLine)
                    .HasColumnType("decimal(6, 2)")
                    .HasColumnName("cost_line");

                entity.Property(e => e.Isbn)
                    .IsRequired()
                    .HasMaxLength(12)
                    .IsUnicode(false)
                    .HasColumnName("isbn")
                    .IsFixedLength(true);

                entity.Property(e => e.OrderNumb).HasColumnName("order_numb");

                entity.Property(e => e.Quantity).HasColumnName("quantity");

                entity.Property(e => e.Shipped)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("shipped")
                    .HasDefaultValueSql("('N')")
                    .IsFixedLength(true);
            });

            modelBuilder.Entity<HarringtonPublisher>(entity =>
            {
                entity.HasKey(e => e.PublisherName)
                    .HasName("PK__harringt__8DBCD413B9ED10CC");

                entity.ToTable("harrington_publishers");

                entity.Property(e => e.PublisherName)
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .HasColumnName("publisher_name");
            });

            modelBuilder.Entity<HarringtonSource>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("harrington_sources");

                entity.Property(e => e.SourceCity)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("source_city");

                entity.Property(e => e.SourceName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("source_name");

                entity.Property(e => e.SourceNumb).HasColumnName("source_numb");

                entity.Property(e => e.SourcePhone)
                    .IsRequired()
                    .HasMaxLength(12)
                    .IsUnicode(false)
                    .HasColumnName("source_phone");

                entity.Property(e => e.SourceState)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("source_state")
                    .IsFixedLength(true);

                entity.Property(e => e.SourceStreet)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("source_street");

                entity.Property(e => e.SourceZip)
                    .IsRequired()
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("source_zip")
                    .IsFixedLength(true);
            });

            modelBuilder.Entity<Order>(entity =>
            {
                entity.Property(e => e.OrderId).ValueGeneratedNever();

                entity.Property(e => e.CustomerId).HasColumnName("CustomerID");

                entity.Property(e => e.OrderDate).HasColumnType("date");

                entity.HasOne(d => d.Customer)
                    .WithMany(p => p.Orders)
                    .HasForeignKey(d => d.CustomerId)
                    .HasConstraintName("FK_Customers");
            });

            modelBuilder.Entity<OrderDetail>(entity =>
            {
                entity.HasKey(e => new { e.OrderId, e.ProductId });

                entity.Property(e => e.UnitPrice).HasColumnType("decimal(5, 2)");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.OrderDetails)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Products");
            });

            modelBuilder.Entity<OrdersByMonth>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("Orders_By_Month");

                entity.Property(e => e.OrdersPerMonth).HasColumnName("Orders per Month");
            });

            modelBuilder.Entity<OrdersCustomer>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("Orders_Customer");

                entity.Property(e => e.Customer)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.CustomerId).HasColumnName("CustomerID");

                entity.Property(e => e.OrderNumber).HasColumnName("Order Number");
            });

            modelBuilder.Entity<PriceAudit>(entity =>
            {
                entity.HasKey(e => e.ChangeId)
                    .HasName("PK__Price_Au__0E05C5B757D08F04");

                entity.ToTable("Price_Audits");

                entity.Property(e => e.ChangeId).HasColumnName("ChangeID");

                entity.Property(e => e.Operation)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Price).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.ProductDetails)
                    .IsRequired()
                    .IsUnicode(false)
                    .HasColumnName("Product_Details");

                entity.Property(e => e.ProductId).HasColumnName("ProductID");

                entity.Property(e => e.UpdatedAt)
                    .HasColumnType("datetime")
                    .HasColumnName("Updated_At");
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.Property(e => e.ProductDetails)
                    .IsRequired()
                    .IsUnicode(false)
                    .HasColumnName("Product_Details");
            });

            modelBuilder.Entity<SalesByCustomer>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("SalesByCustomer");

                entity.Property(e => e.CustName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("Cust_Name");

                entity.Property(e => e.CustomerId).HasColumnName("CustomerID");

                entity.Property(e => e.TotalCost).HasMaxLength(4000);
            });

            modelBuilder.Entity<SalesByMonth>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("Sales_By_Month");

                entity.Property(e => e.Month).HasColumnName("MONTH");

                entity.Property(e => e.OrdersMonth).HasColumnName("Orders/Month");

                entity.Property(e => e.Year).HasColumnName("YEAR");
            });

            modelBuilder.Entity<SalesCustomerFloat>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("Sales_Customer_Float");

                entity.Property(e => e.CustName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("Cust_Name");

                entity.Property(e => e.CustomerId).HasColumnName("CustomerID");

                entity.Property(e => e.TotalCost).HasMaxLength(4000);
            });

            modelBuilder.Entity<StockOrder>(entity =>
            {
                entity.ToTable("StockOrder");

                entity.Property(e => e.StockOrderId).HasColumnName("StockOrderID");

                entity.Property(e => e.ProductDetails)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.Updated).HasColumnType("datetime");
            });

            modelBuilder.Entity<StockOrderRequired>(entity =>
            {
                entity.HasKey(e => e.ProductId)
                    .HasName("PK_StockOrderReqd");

                entity.ToTable("StockOrderRequired");

                entity.Property(e => e.ProductId).ValueGeneratedNever();

                entity.Property(e => e.ProductDetails)
                    .IsRequired()
                    .IsUnicode(false)
                    .HasColumnName("Product_Details");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
