﻿using System;
using System.Collections.Generic;

#nullable disable

namespace UnitFourMVC
{
    public partial class OrdersCustomer
    {
        public int CustomerId { get; set; }
        public string Customer { get; set; }
        public int OrderNumber { get; set; }
    }
}
