﻿using System;
using System.Collections.Generic;

#nullable disable

namespace UnitFourMVC
{
    public partial class PriceAudit
    {
        public int ChangeId { get; set; }
        public int ProductId { get; set; }
        public string ProductDetails { get; set; }
        public decimal Price { get; set; }
        public DateTime UpdatedAt { get; set; }
        public string Operation { get; set; }
    }
}
