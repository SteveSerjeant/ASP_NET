﻿using System;
using System.Collections.Generic;

#nullable disable

namespace UnitFourMVC
{
    public partial class HarringtonSource
    {
        public int SourceNumb { get; set; }
        public string SourceName { get; set; }
        public string SourceStreet { get; set; }
        public string SourceCity { get; set; }
        public string SourceState { get; set; }
        public string SourceZip { get; set; }
        public string SourcePhone { get; set; }
    }
}
