﻿using System;
using System.Collections.Generic;

#nullable disable

namespace UnitFourMVC
{
    public partial class SalesCustomerFloat
    {
        public int CustomerId { get; set; }
        public string CustName { get; set; }
        public int OrderId { get; set; }
        public string TotalCost { get; set; }
    }
}
