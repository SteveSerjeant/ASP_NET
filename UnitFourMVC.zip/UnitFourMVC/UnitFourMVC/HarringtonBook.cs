﻿using System;
using System.Collections.Generic;

#nullable disable

namespace UnitFourMVC
{
    public partial class HarringtonBook
    {
        public string Isbn { get; set; }
        public string AuthorName { get; set; }
        public string Title { get; set; }
        public string PublisherName { get; set; }
        public string PublicationYear { get; set; }
        public string Binding { get; set; }
        public int SourceNumb { get; set; }
        public decimal RetailPrice { get; set; }
        public int NumberOnHand { get; set; }
    }
}
