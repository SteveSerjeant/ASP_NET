﻿using System;
using System.Collections.Generic;

#nullable disable

namespace UnitFourMVC
{
    public partial class HarringtonAuthor
    {
        public string AuthorName { get; set; }
    }
}
