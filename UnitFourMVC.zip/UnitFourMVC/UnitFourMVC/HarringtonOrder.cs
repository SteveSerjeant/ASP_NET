﻿using System;
using System.Collections.Generic;

#nullable disable

namespace UnitFourMVC
{
    public partial class HarringtonOrder
    {
        public int OrderNumb { get; set; }
        public int CustomerNumb { get; set; }
        public DateTime OrderDate { get; set; }
        public string CreditCardNumb { get; set; }
        public string CreditCardExpirationDate { get; set; }
        public string OrderFilled { get; set; }
    }
}
