﻿using System;
using System.Collections.Generic;

#nullable disable

namespace UnitFourMVC
{
    public partial class SalesByCustomer
    {
        public int OrderId { get; set; }
        public int CustomerId { get; set; }
        public string CustName { get; set; }
        public string TotalCost { get; set; }
    }
}
