﻿using System;
using System.Collections.Generic;

#nullable disable

namespace UnitFourMVC
{
    public partial class HarringtonPublisher
    {
        public string PublisherName { get; set; }
    }
}
