﻿using System;
using System.Collections.Generic;

#nullable disable

namespace UnitFourMVC
{
    public partial class SalesByMonth
    {
        public int? Year { get; set; }
        public int? Month { get; set; }
        public int? OrdersMonth { get; set; }
    }
}
